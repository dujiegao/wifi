﻿using MQTTnet;
using MQTTnet.Core;
using MQTTnet.Core.Client;
using MQTTnet.Core.Packets;
using MQTTnet.Core.Protocol;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace mqtt
{
    public partial class Form1 : Form
    {
        MqttClient mqttClient = null;
        MqttClientTcpOptions options;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "连接")
            {
                //if (mqttClient == null)
                {
                    label8.Text = "尝试连接";

                    options = new MqttClientTcpOptions();
                    mqttClient = new MqttClientFactory().CreateMqttClient() as MqttClient;

                    mqttClient.ApplicationMessageReceived += client_MqttMsgPublishReceived;
                    mqttClient.Connected += MqttClient_Connected;
                    mqttClient.Disconnected += MqttClient_Disconnected;

                    try
                    {
                        IPHostEntry host = Dns.GetHostByName(textBox3.Text.ToString());
                        IPAddress ip = host.AddressList[0];

                        options.Server = ip.ToString();
                        options.Port = int.Parse(textBox4.Text.ToString());
                        options.KeepAlivePeriod = new TimeSpan(0,0,60);

                        string clientid = textBox9.Text.ToString();
                        if (clientid.Length == 0)
                        {
                            options.ClientId = Guid.NewGuid().ToString().Substring(0, 10);
                        }
                        else
                        {
                            options.ClientId = clientid;
                        }
                        //textBox8.AppendText("连接MQTT服务器失败！" + clientid.Length);

                        options.UserName = textBox1.Text.ToString();
                        options.Password = textBox2.Text.ToString();
                        mqttClient.ConnectAsync(options);
                    }
                    catch (Exception ex)
                    {
                        label8.Text = "连接失败";
                        textBox8.AppendText("连接MQTT服务器失败！" + Environment.NewLine + ex.Message + Environment.NewLine);
                    }
                }
                
            }
            else
            {
                mqttClient.DisconnectAsync();
                button1.Text = "连接";
                label8.Text = "连接断开";
            }

        }

        private void MqttClient_Connected(object sender, EventArgs e)
        {
            Invoke((new Action(() =>
            {
                label8.Text = "成功连接";
                button1.Text = "断开";
            })));
        }

        private void MqttClient_Disconnected(object sender, EventArgs e)
        {
            Invoke((new Action(() =>
            {
                label8.Text = "连接断开";
                button1.Text = "连接";
            })));
            
        }


        private void client_MqttMsgPublishReceived(object sender, MqttApplicationMessageReceivedEventArgs e)
        {
            string stringTopic = e.ApplicationMessage.Topic;//发过来的主题
            string stringData = Encoding.Default.GetString(e.ApplicationMessage.Payload);//发过来的消息
            string stringDataCopy = "\r\n时间:" + DateTime.Now.ToString() + "\r\n" + "主题:" + stringTopic + "\r\n字符串数据:" + stringData + "\r\n";
            
            Invoke((new Action(() =>
            {
                textBox8.AppendText(stringDataCopy);

                textBox8.AppendText("\r\n16进制数据:" + ToHexString(e.ApplicationMessage.Payload)+ "\r\n");
            })));

        }

        public static string ToHexString(byte[] bytes) // 0xae00cf => "AE00CF "
        {
            string hexString = string.Empty;

            if (bytes != null)
            {
                StringBuilder strB = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    strB.Append(bytes[i].ToString("X2")+" ");
                }
                hexString = strB.ToString();
            }
            return hexString;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox2.Checked)//字符发送
            {
                byte[] sendbyte = strToToHexByte(textBox7.Text.ToString());//字符串转16进制格式,不够自动前面补零
                if (sendbyte != null && sendbyte.Length > 0)
                {
                    try
                    {
                        var appMsg = new MqttApplicationMessage(textBox6.Text, sendbyte, MqttQualityOfServiceLevel.AtMostOnce, false);
                        mqttClient.PublishAsync(appMsg);
                    }
                    catch (Exception ex)
                    {
                        Invoke((new Action(() =>
                        {
                            label8.Text = "连接断开";
                            textBox8.AppendText("发送数据错误！" + Environment.NewLine + ex.Message + Environment.NewLine);
                            button1.Text = "连接";
                        })));
                        if (mqttClient != null)
                        {
                            mqttClient.DisconnectAsync();
                        }
                    }
                }
            }
            else
            {
                try
                {
                    var appMsg = new MqttApplicationMessage(textBox6.Text, Encoding.UTF8.GetBytes(textBox7.Text.ToString()), MqttQualityOfServiceLevel.AtMostOnce, false);
                    mqttClient.PublishAsync(appMsg);
                }
                catch (Exception ex)
                {
                    Invoke((new Action(() =>
                    {
                        label8.Text = "连接断开";
                        textBox8.AppendText("发送数据错误！" + Environment.NewLine + ex.Message + Environment.NewLine);
                        button1.Text = "连接";
                    })));
                    if (mqttClient != null)
                    {
                        mqttClient.DisconnectAsync();
                    }
                }
            }
        }

        /// <字符串转16进制格式,不够自动前面补零>
        /// "0054FF"  ==>  16进制  0x00 0x54 0xFF
        /// </summary>
        /// <param name="hexString"></param>
        /// <returns></returns>
        private static byte[] strToToHexByte(String hexString)
        {
            int i;
            bool Flag = false;


            hexString = hexString.Replace(" ", "");//清除空格
            if ((hexString.Length % 2) != 0)
            {
                Flag = true;
            }
            if (Flag == true)
            {
                byte[] returnBytes = new byte[(hexString.Length + 1) / 2];

                try
                {
                    for (i = 0; i < (hexString.Length - 1) / 2; i++)
                    {
                        returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
                    }
                    returnBytes[returnBytes.Length - 1] = Convert.ToByte(hexString.Substring(hexString.Length - 1, 1).PadLeft(2, '0'), 16);

                }
                catch
                {
                    for (i = 0; i < returnBytes.Length; i++)
                    {
                        returnBytes[i] = 0;
                    }
                    MessageBox.Show("超过16进制范围A-F", "提示");
                    return null;
                }
                return returnBytes;
            }
            else
            {
                byte[] returnBytes = new byte[(hexString.Length) / 2];
                try
                {
                    for (i = 0; i < returnBytes.Length; i++)
                    {
                        returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
                    }
                }
                catch
                {
                    for (i = 0; i < returnBytes.Length; i++)
                    {
                        returnBytes[i] = 0;
                    }
                    MessageBox.Show("超过16进制范围A-F", "提示");
                    return null;
                }
                return returnBytes;
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                mqttClient.SubscribeAsync(new List<TopicFilter> { new TopicFilter(textBox5.Text, MqttQualityOfServiceLevel.AtMostOnce) });
                Invoke((new Action(() =>
                {
                    textBox8.AppendText("订阅主题:" + textBox5.Text + Environment.NewLine);
                })));
            }
            catch (Exception ex)
            {
                Invoke((new Action(() =>
                {
                    label8.Text = "连接断开";
                    textBox8.AppendText("订阅失败！" + ex.Message + Environment.NewLine);
                    button1.Text = "连接";
                })));
                if (mqttClient != null)
                {
                    mqttClient.DisconnectAsync();
                }
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox8.Text = "";
        }
    }
}
